﻿namespace Easter.Models.Dyes
{
    using Contracts;

    public class Dye : IDye
    {
        public Dye(int power)
        {
            this.Power = power;
        }

        public int Power { get; private set; }

        public void Use()
        {
            Power -= 10;

            if (Power < 0)
            {
                Power = 0;
            }
        }

        public bool IsFinished() =>  Power == 0;
    }
}