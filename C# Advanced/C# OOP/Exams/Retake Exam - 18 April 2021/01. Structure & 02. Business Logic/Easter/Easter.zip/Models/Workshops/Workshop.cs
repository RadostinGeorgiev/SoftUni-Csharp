﻿namespace Easter.Models.Workshops
{
    using System.Linq;
    using Bunnies.Contracts;
    using Contracts;
    using Eggs.Contracts;

    public class Workshop : IWorkshop
    {
        public void Color(IEgg egg, IBunny bunny)
        {
            while (!egg.IsDone()) 
            {
                if (bunny.Energy == 0)
                {
                    break;
                }

                if (bunny.Dyes.Count == 0)
                {
                    break;
                }

                bunny.Work();
                egg.GetColored();
            }
        }
    }
}