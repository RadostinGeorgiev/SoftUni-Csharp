﻿using System;
using System.Collections.Generic;
using WildFarm.Factory;
using WildFarm.Models.Animals.Interfaces;
using WildFarm.Models.Foods.Interfaces;

namespace WildFarm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            AnimalCreator animalCreator = new AnimalCreator();
            FoodCreator foodCreator = new FoodCreator();
            ICollection<IAnimal> animals = new List<IAnimal>();


            string input;
            while ((input = Console.ReadLine()) != "End")
            {
                IAnimal animal = null;
                IFood food;

                try
                {
                    string[] animalArgs = input
                       .Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    animal = animalCreator.AnimalFactory(animalArgs);
                    Console.WriteLine(animal.ProduceSound());
                    animals.Add(animal);

                    string[] foodArgs = Console.ReadLine()
                        .Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    food = foodCreator.FoodFactory(foodArgs);

                    animal.Feed(food);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            foreach (var animal in animals)
            {
                Console.WriteLine(animal);
            }
        }
    }
}