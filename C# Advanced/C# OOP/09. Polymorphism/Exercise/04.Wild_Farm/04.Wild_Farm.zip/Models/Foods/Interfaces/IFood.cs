﻿namespace WildFarm.Models.Foods.Interfaces
{
    public interface IFood
    {
        public int Quantity { get; }

    }
}