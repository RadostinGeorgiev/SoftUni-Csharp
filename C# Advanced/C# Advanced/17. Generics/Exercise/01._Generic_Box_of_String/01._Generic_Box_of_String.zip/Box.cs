﻿namespace _01._Generic_Box_of_String
{
    public class Box<T>
    {
        private T data;
        public Box(T item)
        {
            data = item;
        }

        public override string ToString()
        {
            return $"{data.GetType()}: {data}";
        }
    }
}